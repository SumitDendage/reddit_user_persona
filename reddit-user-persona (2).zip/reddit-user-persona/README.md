# reddit_user_persona
This project analyzes Reddit user profiles by scraping posts and comments, then uses an LLM to generate insightful user personas with source citations. Built with Python, Reddit API, and Open AI.
